import os
from os import getcwd
import subprocess
import time
import shutil
from PIL import Image
import numpy as np
import tensorflow as tf
from tensorflow.keras.models import Sequential, model_from_json
import csv

print("--------------------------------------------")
print("---------------CNN CLASSIFIER---------------")
print("--------------------------------------------")

darknet_path = getcwd()
predictor_path = os.path.join(darknet_path, 'predictor')

print("Finding input images")

INPUT_IMAGES_PATH = os.path.join(predictor_path, 'input_images')
OUTPUT_PATH = os.path.join(predictor_path, 'output')

print("Calculating parameters for YOLO")

im_paths = os.listdir(INPUT_IMAGES_PATH)
output_paths = os.listdir(OUTPUT_PATH)

print("Loading CNN model")

# Clean output folder
for file in output_paths:
    file_path = os.path.join(OUTPUT_PATH, file)
    os.remove(file_path)

# Load json and create CNN model
json_file = open('cnn_model_files\model1.json', 'r')
loaded_model_json = json_file.read()
json_file.close()
loaded_model = model_from_json(loaded_model_json)

# Load weights into model
loaded_model.load_weights("cnn_model_files\model1.h5")

print("Compiling CNN model from disk")

# Compile CNN loaded model

img_height, img_width = 224, 224
loaded_model.compile(loss='binary_crossentropy', optimizer='rmsprop', metrics=['accuracy'])

csv_output = []
# Create predictions for each image
for im in im_paths:
    if len(im) == 0:
        continue

    image_path = os.path.join(INPUT_IMAGES_PATH, im)
    image_name = (im.split('/')[-1]).split('.')[0]

    print("Predicting class via CNN model")

    # Predicting image via CNN model
    X = []
    if (os.path.isfile(image_path)):
        image = Image.open(image_path)
        img = image.resize((img_height, img_width))
        X.append(np.array(img) / 255.0)

    X = np.array(X)

    cnn_prediction_softmax = loaded_model.predict(X)
    cnn_prediction_class = np.argmax(cnn_prediction_softmax, axis=1)

    print("CNN prediction : ", cnn_prediction_class[0], " (0-Real, 1-Synthetic)")

    csv_output.append([image_name, cnn_prediction_class[0]])

print("Creating a CSV output file")

with open( os.path.join(OUTPUT_PATH,'Predictor.csv'), 'w', newline='') as file:
    writer = csv.writer(file)
    writer.writerow(["Image name", "CNN Prediction (0-Real, 1-Synthetic)"])
    writer.writerows(csv_output)
